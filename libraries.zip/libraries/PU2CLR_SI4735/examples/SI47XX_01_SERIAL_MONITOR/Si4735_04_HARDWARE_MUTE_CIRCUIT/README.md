# Proof of Concept for SI4735 Arduino Library 

## About SI4735_POC.ino

This project is a proof of concept for SI4735 device controlled by Arduino and the SI4735 Library. This Arduino Sketch only works when connected to your IDE (Arduino IDE Serial Monitor). However, you can replace the Serial functions with functions that utilize rotary encoders, buttons, LCD screens, etc. Thus making it not require a connection to the Serial Monitor.

[PU2CLR Si47XX API documentation](https://pu2clr.github.io/SI4735/extras/apidoc/html/)

