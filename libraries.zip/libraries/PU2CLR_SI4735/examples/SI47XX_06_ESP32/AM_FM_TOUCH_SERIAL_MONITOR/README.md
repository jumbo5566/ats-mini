# Proof of Concept for SI4735 Arduino Library 

## About SI4735_POC.ino

This project is a proof of concept for SI4735 device controlled by Arduino and the SI4735 Library. This Arduino Sketch only works when connected to a serial monitor (like the Arduino IDE serial monitor). However, you can replace the Serial Monitor functions with functions that interact with devices like rotarty encoders, buttons, and LCD screens.

